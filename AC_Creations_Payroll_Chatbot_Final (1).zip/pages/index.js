import React, { useState } from 'react';

export default function Home() {
  const [question, setQuestion] = useState('');
  const [response, setResponse] = useState('');

  const askAI = async () => {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question }),
    });
    const data = await res.json();
    setResponse(data.answer);
  };

  return (
    <main style={{ padding: 20 }}>
      <h1>AC Creations Payroll Chatbot</h1>
      <textarea
        value={question}
        onChange={(e) => setQuestion(e.target.value)}
        rows={4}
        cols={50}
        placeholder="Ask your payroll compliance question..."
      />
      <br />
      <button onClick={askAI}>Ask</button>
      <div style={{ marginTop: 20 }}>
        <strong>Answer:</strong>
        <p>{response}</p>
      </div>
    </main>
  );
}